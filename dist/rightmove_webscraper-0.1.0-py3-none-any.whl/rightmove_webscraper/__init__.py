
from .scraper import RightmoveData
